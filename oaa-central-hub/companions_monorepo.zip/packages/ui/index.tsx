import React from 'react';
export function Header({ title }: { title: string }){
  return (
    <header style={{padding:'12px 16px',borderBottom:'1px solid #1f2a44',background:'#0b1020',color:'#cfe0ff'}}>
      <strong>{title}</strong>
    </header>
  );
}
