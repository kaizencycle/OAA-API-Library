import Link from "next/link";
import { Header } from "@civic/ui";

export default function Home() {
  return (
    <main style={minHeight:'100vh',background:'#050914',color:'#cfe0ff'}>
      <Header title="Hermes — Companion Home" />
      <div style={maxWidth:720,margin:'40px auto',padding:'0 20px'}>
        <h1 style={marginBottom:6}>Hermes</h1>
        <p>Welcome to Hermes's site. Open the hologram or hit the tools.</p>
        <p><Link href="/holo" style={color:'#9fd1ff'}>Open Holo</Link></p>
        <ul>
          <li><code>GET /api/tools/status</code></li>
          <li><code>POST /api/tools/ping</code></li>
        </ul>
      </div>
    </main>
  );
}
