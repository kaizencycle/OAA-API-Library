# Companions Monorepo
Four companion sites (Jade, Zeus, Eve, Hermes) with shared UI and CI.

## Use
```bash
npm i
npm -w apps/jade-site run dev
# open http://localhost:3000
```

## Deploy (Render)
Use `render.yaml` to create four web services. Map DNS:
- jade.yourdomain.com → Jade site
- zeus.yourdomain.com → Zeus site
- eve.yourdomain.com → Eve site
- hermes.yourdomain.com → Hermes site
